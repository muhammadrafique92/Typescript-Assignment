let n = ['Imran Khan', 'Zia Khan', ' Abdul Qadeer Khan', ' Ali Muhammad Khan', 'Qasim Khan'];

console.log(n[6]);
console.log(n.length);
console.log(n[4]);