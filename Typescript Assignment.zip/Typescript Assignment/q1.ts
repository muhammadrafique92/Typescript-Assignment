//install nodejs and typescript and vscode

// nodejs installed from nodejs website

// npm install --global typescript

// vscode installed from vscode website