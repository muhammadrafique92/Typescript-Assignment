let fname = "Muhammad Rafique"
console.log('Hello! '+  fname + ',' +' would you like to learn some typescript today?');
