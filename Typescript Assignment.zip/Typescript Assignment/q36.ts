function make_shirt(size,msg){
    console.log('-----------------------make_shirt function----------------------------')
    console.log('The size is: ' + size + '\nand message on shirt is: "'+ msg +'"')
}


make_shirt('medium','Just do it')
make_shirt('large','Lost in the thought')

