let alien = {
    'color' : 'green'
}

if(alien['color'] == 'green'){
    console.log('you have scored 5 points');
}

else{
    console.log('you have scored 10 points');
}