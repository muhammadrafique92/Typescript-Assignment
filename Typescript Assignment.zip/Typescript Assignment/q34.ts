let pizzas = ['tikka','fajita','hot and spicy']

for(let i in pizzas){
    const pizza = pizzas[i]

    console.log(pizza)
}
console.log('-------------------------------------------------------')

for(let i in pizzas){
    const pizza = pizzas[i]

    console.log('i like ' + pizza + ' pizza')
}
console.log('-------------------------------------------------------')
console.log('pizza was invented in italy\nIt was simple to serve to travellers\nit is really delicious food')