let sentences=['I would like to buy a ', 'I would like to ride a ', 'I would like to walsh a '];

for (let index = 0; index < sentences.length; index++) {
    result = sentences[index];

    console.log(result+ 'Car');
    
}