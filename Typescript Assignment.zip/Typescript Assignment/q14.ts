let n = ['Imran Khan', 'Zia Khan', ' Abdul Qadeer Khan', ' Ali Muhammad Khan', 'Qasim Khan'];

for (let index = 0; index < n.length; index++) {
    result = n[index];
    

console.log('Hello! dear ' + result + ',' + ' Please come to serana hotel tonight for dinner.');

}