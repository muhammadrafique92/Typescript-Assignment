let n = ['Imran Khan', 'Zia Khan', ' Abdul Qadeer Khan', ' Ali Muhammad Khan', 'Qasim Khan'];

console.log(n.length + ' guests have been invited');