let cities = ['Madina','Istanbul', 'Rome', 'Dubai', 'Karachi'];

console.log(cities);

let sorted = [...cities];
sorted.sort();
console.log(sorted);

console.log(cities);

let reversed = [...sorted];
reversed.reverse();
console.log(reversed);

console.log(cities);

cities.reverse();
console.log(cities);

cities.reverse();
console.log(cities);

cities.sort();
console.log(cities);

cities.reverse();
console.log(cities);
