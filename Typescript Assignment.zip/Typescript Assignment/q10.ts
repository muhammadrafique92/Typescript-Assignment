let x = " author : Muhammad Rafique";

let famous_person = "Imran Khan";

let quote = "\"The more you study, the more you know; how less you know.\"";

let message = famous_person + " once said, " + quote;

console.log(x);

console.log('This program displays quote of Imran khan');

console.log(message);
