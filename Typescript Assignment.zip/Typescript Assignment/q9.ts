let x=92;

message = "My fovouritr number is " + x;

console.log(message);