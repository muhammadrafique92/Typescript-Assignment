let pets=['Dog','Cat','Rabbit']

for(let i in pets){
    const pet=pets[i]
    console.log(pet)
}

for(let i in pets){
    const pet=pets[i]
    console.log(pet + ' would make a great pet')
}
console.log('these all are cute animals & Any of them will make a great pet')