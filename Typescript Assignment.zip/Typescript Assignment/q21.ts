let car = {
    'make': 'suzuki',
    'model': 'kei',
    'engine': 'dohc'
}

console.log(car);
console.log('the type of car is: ' + typeof(car));