console.log(5+3);

console.log(15-7);

console.log(4*2);

console.log(16/2);