let num = 1200;

if(num % 2 == 0){
    console.log('number: ' + num + ' is divisible by 2');
}

if(num % 3 == 0){
    console.log('number: ' + num + ' is divisible by 3');
}

if(num % 4 == 0){
    console.log('number: ' + num + ' is divisible by 4');
}

if(num % 5 == 0){
    console.log('number: ' + num + ' is divisible by 5');
}

if(num % 6 == 0){
    console.log('number: ' + num + ' is divisible by 6');
}

if(num % 7 == 0){
    console.log('number: ' + num + ' is divisible by 7');
}

if(num % 9 == 0){
    console.log('number: ' + num + ' is divisible by 9');
}

if(num % 11 == 0){
    console.log('number: ' + num + ' is divisible by 11');
}

if(num % 13 == 0){
    console.log('number: ' + num + ' is divisible by 13');
}

if(num % 14 == 0){
    console.log('number: ' + num + ' is divisible by 14');
}
