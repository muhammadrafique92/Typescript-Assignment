function city_country(city,country){
    console.log('"' + city +  ', ' +  country + '"')
}

city_country('lahore','pakistan')
city_country('Karachi','Pakistan')
city_country('Islamabad','Pakistan')