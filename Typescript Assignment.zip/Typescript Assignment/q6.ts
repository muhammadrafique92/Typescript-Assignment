let person= '\tDr.Abdul Qadeer Khan\n'
console.log(person);
console.log(person.trim());