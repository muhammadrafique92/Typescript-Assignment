let rivers = new Array('sindh','ravi','jehlum','kabul','neelam','chenab');

console.log('rivers array created with new Array function');
console.log(rivers);
console.log('the type of rivers array is: ' + typeof(rivers) + ' and length is: ' + rivers.length);


let cities = ['karachi','lahore'];
console.log('cities array created with []');
console.log(cities);
console.log('the type of cities array is: ' + typeof(cities) + ' and length is: ' + cities.length);