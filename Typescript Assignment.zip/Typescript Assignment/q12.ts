let names = ['Ayub','Shahbaz','Kashif','Asif','Mubeen','Azhar'];

for (let index = 0; index < names.length; index++) {
    result = names[index];

    console.log("Hello! Mr." + result + ',' + " Mango party is arranged at my home tommorrow, you are invited.")

}