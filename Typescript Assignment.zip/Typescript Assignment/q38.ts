function describe_city(city, country='Pakistan') {
    console.log(city + ' is in the ' + country)
   
}
describe_city('Lahore')
describe_city('karachi')
describe_city('paris', 'France')