let alien = {
    'color' : 'yellow'
}

if(alien['color'] == 'green'){
    console.log('you have scored 5 points');
}

else if(alien['color'] == 'yellow'){
    console.log('you have scored 10 points');
}
else if(alien['color'] == 'red'){
    console.log('you have scored 15 points');
}
