
let alien = {
    'color' : 'red'
}


if(alien['color'] == 'green'){
    console.log('you have scored 5 points');
}
